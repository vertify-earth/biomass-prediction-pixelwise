import os
import sys
import shutil
import argparse
import logging
from pathlib import Path

# Configure logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def prepare_huggingface_repo(model_dir, hf_repo_path, readme=None):
    """
    Prepare a directory for Hugging Face deployment
    
    Args:
        model_dir: Directory containing model files
        hf_repo_path: Path where to create the HF repo
        readme: Path to README.md file (optional)
    """
    # Create repo directory
    os.makedirs(hf_repo_path, exist_ok=True)
    
    # Copy model files
    required_files = ['model.pt', 'model_package.pkl']
    for file in required_files:
        src_path = os.path.join(model_dir, file)
        if os.path.exists(src_path):
            shutil.copy(src_path, os.path.join(hf_repo_path, file))
            logger.info(f"Copied {file} to {hf_repo_path}")
        else:
            logger.error(f"Required file not found: {src_path}")
            return False
    
    # Copy app.py
    app_path = os.path.join(Path(__file__).parent, 'app.py')
    if os.path.exists(app_path):
        shutil.copy(app_path, os.path.join(hf_repo_path, 'app.py'))
        logger.info(f"Copied app.py to {hf_repo_path}")
    else:
        logger.error(f"Required file not found: {app_path}")
        return False
    
    # Copy model.py (required by app.py)
    model_py_path = os.path.join(Path(__file__).parent, 'model.py')
    if os.path.exists(model_py_path):
        shutil.copy(model_py_path, os.path.join(hf_repo_path, 'model.py'))
        logger.info(f"Copied model.py to {hf_repo_path}")
    else:
        logger.error(f"Required file not found: {model_py_path}")
        return False
    
    # Create requirements.txt
    with open(os.path.join(hf_repo_path, 'requirements.txt'), 'w') as f:
        f.write('\n'.join([
            'torch>=1.10.0',
            'rasterio>=1.2.0',
            'numpy>=1.20.0',
            'scikit-learn>=1.0.0',
            'matplotlib>=3.5.0',
            'gradio>=3.0.0',
            'joblib>=1.1.0',
            'pillow>=8.0.0'
        ]))
        logger.info("Created requirements.txt")
    
    # Create or copy README.md
    if readme and os.path.exists(readme):
        shutil.copy(readme, os.path.join(hf_repo_path, 'README.md'))
        logger.info(f"Copied README.md from {readme}")
    else:
        # Create basic README
        with open(os.path.join(hf_repo_path, 'README.md'), 'w') as f:
            f.write("""# Biomass Prediction Model

This repository contains a trained model for predicting above-ground biomass (AGB) from satellite imagery.

## Model Description

The model uses a StableResNet architecture to predict biomass values from multi-spectral satellite imagery on a per-pixel basis.

## Usage

1. Upload a multi-band satellite image (GeoTIFF)
2. Select the display type (heatmap or RGB overlay)
3. Click "Generate Biomass Prediction"
4. View the resulting biomass map and statistics

## Requirements

- The image must be in GeoTIFF format
- The image should contain multiple spectral bands similar to those used in training

## Model Details

- Architecture: StableResNet
- Input: Multi-spectral satellite data
- Output: Above-ground biomass in Mg/ha (megagrams per hectare)
- Creator: najahpokkirii
- Date: 2025-05-16

""")
        logger.info("Created basic README.md")
    
    # Create .gitignore
    with open(os.path.join(hf_repo_path, '.gitignore'), 'w') as f:
        f.write('\n'.join([
            '__pycache__/',
            '*.py[cod]',
            '*$py.class',
            '.ipynb_checkpoints',
            '.env',
            '.venv',
            'env/',
            'venv/',
            'ENV/',
            '.DS_Store'
        ]))
        logger.info("Created .gitignore")
    
    logger.info(f"HuggingFace repo prepared at {hf_repo_path}")
    return True

def deploy_to_huggingface(hf_repo_path, hf_repo_id, token=None):
    """
    Deploy the model to HuggingFace Hub
    
    Args:
        hf_repo_path: Local path to the repo
        hf_repo_id: HuggingFace repo ID (username/repo-name)
        token: HuggingFace token (optional)
    """
    try:
        from huggingface_hub import HfApi, create_repo
        
        # Create or get repo
        api = HfApi()
        
        if token:
            # Create repo if it doesn't exist
            try:
                create_repo(hf_repo_id, private=False, token=token)
                logger.info(f"Created repository: {hf_repo_id}")
            except Exception as e:
                logger.info(f"Repository may already exist: {e}")
                
            # Upload files
            api.upload_folder(
                folder_path=hf_repo_path,
                repo_id=hf_repo_id,
                token=token
            )
        else:
            # If no token provided, just upload folder
            api.upload_folder(
                folder_path=hf_repo_path,
                repo_id=hf_repo_id
            )
        
        logger.info(f"Model deployed to HuggingFace Hub: {hf_repo_id}")
        logger.info(f"View at: https://huggingface.co/spaces/{hf_repo_id}")
        return True
    
    except ImportError:
        logger.error("huggingface_hub package not installed. Please install with: pip install huggingface_hub")
        return False
    except Exception as e:
        logger.error(f"Error deploying to HuggingFace: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Deploy biomass model to HuggingFace')
    parser.add_argument('--model_dir', type=str, required=True, help='Directory containing model files')
    parser.add_argument('--hf_repo_id', type=str, required=True, help='HuggingFace repo ID (username/repo-name)')
    parser.add_argument('--token', type=str, help='HuggingFace token')
    parser.add_argument('--readme', type=str, help='Path to README.md file')
    
    args = parser.parse_args()
    
    # Create temp directory for HF repo
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        # Prepare repo
        success = prepare_huggingface_repo(args.model_dir, tmp_dir, args.readme)
        
        if success:
            # Deploy to HuggingFace
            deploy_to_huggingface(tmp_dir, args.hf_repo_id, args.token)