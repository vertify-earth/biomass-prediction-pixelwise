# Biomass Prediction Pipeline

This repository contains a complete pipeline for predicting above-ground biomass (AGB) from satellite imagery using deep learning.

## Overview

The biomass prediction pipeline includes:

1. **Data Processing** - Loading and preprocessing satellite imagery and ground-truth biomass data
2. **Feature Engineering** - Creating spectral indices, texture features, and spatial context features
3. **Model Training** - Training the StableResNet model for biomass regression
4. **Model Evaluation** - Comprehensive evaluation with metrics and visualizations
5. **Deployment** - HuggingFace Gradio app for interactive biomass prediction

## StableResNet Architecture

The core of the pipeline is the StableResNet architecture, specifically designed for stable biomass regression:

```python
class StableResNet(nn.Module):
    """Numerically stable ResNet for biomass regression"""
    def __init__(self, n_features, dropout=0.2):
        super().__init__()
        
        self.input_proj = nn.Sequential(
            nn.Linear(n_features, 256),
            nn.LayerNorm(256),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        self.layer1 = self._make_simple_resblock(256, 256)
        self.layer2 = self._make_simple_resblock(256, 128)
        self.layer3 = self._make_simple_resblock(128, 64)
        
        self.regressor = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
```

## Installation

```bash
# Clone this repository
git clone https://github.com/najahpokkirii/biomass-prediction.git
cd biomass-prediction

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Quick Test Run

```bash
python main.py --mode test
```

### Full Pipeline Run

```bash
python main.py --mode full --data_dir /path/to/data --results_dir /path/to/results
```

### Deploy to HuggingFace

```bash
python main.py --mode full --deploy --hf_repo yourusername/biomass-model --hf_token YOUR_HF_TOKEN
```

## Workflow

1. **Data Loading**: The pipeline loads satellite images and corresponding biomass maps
2. **Feature Engineering**: Calculates spectral indices, texture features, and spatial context
3. **Training**: Trains the StableResNet model with early stopping
4. **Evaluation**: Calculates R², RMSE, and MAE on test data
5. **Visualization**: Creates plots of predictions vs. ground truth
6. **Deployment**: Packages the model for HuggingFace deployment

## Results

After running the pipeline, you'll find:

- Trained model weights and architecture
- Feature preprocessing pipeline
- Training history and metrics
- Prediction vs. ground truth visualizations
- Ready-to-deploy HuggingFace package

## HuggingFace Gradio App

The included Gradio app provides:

- Interactive interface for uploading satellite images
- Biomass prediction visualization (heatmap or RGB overlay)
- Summary statistics on predicted biomass
- Documentation on model usage and limitations

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- Data sources: Include relevant satellite data providers
- Special thanks to the research community for biomass estimation methodologies